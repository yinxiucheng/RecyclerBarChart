package com.xiaomi.wearable.download;

import android.app.DownloadManager;
import android.content.Context;
import android.os.Environment;
import android.support.annotation.NonNull;

import com.xiaomi.wearable.download.statehandler.StateHandler;
import com.xiaomi.wearable.util.SharePreferenceUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.disposables.CompositeDisposable;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class AppDownloadManagerImplTest {

    private AppDownloadManagerImpl appDownloadManager;
    private SystemDownloadTestImpl systemDownloadImpl;
    private StateHandler stateHandler;
    private DownloadConfig config;
    private Context context;
    private final AtomicInteger updateTimes = new AtomicInteger();

    private static DownloadState copyDownloadState(DownloadState state) {
        DownloadState copy = new DownloadState(state.key, state.downloadId);
        copy.realDownloaded = state.realDownloaded;
        copy.total = state.total;
        copy.localUrl = state.localUrl;
        copy.reason = state.reason;
        copy.status = state.status;
        return copy;
    }

    private static String makeFileAndGetPath(Context context, String dirType, String path) {
        File file = new File(path);
        if (file.exists()) {
            return path;
        }
        file = new File(context.getExternalFilesDir(dirType), path);
        if (file.exists() || file.mkdir()) {
            return file.getAbsolutePath();
        }
        return null;
    }

    private static void deleteFile(Context context, String path) {
        File file = new File(path);
        if (file.exists()) {
            file.delete();
        }

    }

    @Before
    public void setUp() {
        updateTimes.set(0);
        context = RuntimeEnvironment.application;
        SharePreferenceUtil.getInstance().setPreferences(
                context.getSharedPreferences("123", Context.MODE_PRIVATE));
        stateHandler = new StateHandler();
        systemDownloadImpl = new SystemDownloadTestImpl();
        appDownloadManager = new AppDownloadManagerImpl(context, systemDownloadImpl,
                stateHandler, Runnable::run);
        config = new DownloadConfig() {
            @NonNull
            @Override
            public String getDownloadUrl() {
                return "1234567";
            }

            @NonNull
            @Override
            public String getDirType() {
                return Environment.DIRECTORY_DOWNLOADS;
            }

            @NonNull
            @Override
            public String getDownloadFileName() {
                return "123.apk";
            }
        };
    }

    @Test
    public void testDownloadProgressSuccess() {
        DownloadState[] states = new DownloadState[1];
        assertEquals(0, appDownloadManager.listenerSize(config.getKey()));
        //noinspection ResultOfMethodCallIgnored
        appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> {
                    updateTimes.incrementAndGet();
                    states[0] = state;
                });

        assertEquals(1, appDownloadManager.listenerSize(config.getKey()));
        assertEquals(0, updateTimes.get());
        assertNull(stateHandler.getDownloadState(config.getKey()));

        appDownloadManager.startDownloadIfNeed(config);
        assertEquals(1, updateTimes.get());
        assertEquals(states[0], stateHandler.getDownloadState(config.getKey()));

        //Download progress
        DownloadState state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_RUNNING;
        state.total = 100;
        state.downloaded = 30;
        state.realDownloaded = 30;
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(2, updateTimes.get());
        assertEquals(100, states[0].total);
        assertEquals(30, states[0].realDownloaded);
        assertEquals(DownloadManager.STATUS_RUNNING, states[0].status);
        assertEquals(states[0], stateHandler.getDownloadState(config.getKey()));

        //Download complete
        state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_SUCCESSFUL;
        state.total = 100;
        state.downloaded = 100;
        state.realDownloaded = 100;
        state.localUrl = makeFileAndGetPath(context, config.getDirType(),
                config.getDownloadFileName());
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(3, updateTimes.get());
        assertEquals(100, states[0].total);
        assertEquals(100, states[0].realDownloaded);
        assertEquals(DownloadManager.STATUS_SUCCESSFUL, states[0].status);
        assertTrue(states[0].isDone());
        assertEquals(states[0], stateHandler.getDownloadState(config.getKey()));
    }

    @Test
    public void testListenerSize() {
        assertEquals(0, appDownloadManager.listenerSize(config.getKey()));
        CompositeDisposable disposables = new CompositeDisposable();

        disposables.add(appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> updateTimes.incrementAndGet()));
        assertEquals(0, updateTimes.get());
        assertEquals(1, appDownloadManager.listenerSize(config.getKey()));

        disposables.add(appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> updateTimes.incrementAndGet()));
        assertEquals(0, updateTimes.get());
        assertEquals(2, appDownloadManager.listenerSize(config.getKey()));

        disposables.add(appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> updateTimes.incrementAndGet()));
        assertEquals(0, updateTimes.get());
        assertEquals(3, appDownloadManager.listenerSize(config.getKey()));

        disposables.clear();
        appDownloadManager.deleteDownload(config);
        assertEquals(0, updateTimes.get());
        assertEquals(0, appDownloadManager.listenerSize(config.getKey()));
    }

    @Test
    public void testDownloadFail() {
        DownloadState[] states = new DownloadState[1];
        assertEquals(0, appDownloadManager.listenerSize(config.getKey()));
        //noinspection ResultOfMethodCallIgnored
        appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> {
                    updateTimes.incrementAndGet();
                    states[0] = state;
                });
        appDownloadManager.startDownloadIfNeed(config);
        assertEquals(1, updateTimes.get());

        //Download fail
        DownloadState state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_FAILED;
        state.total = 100;
        state.downloaded = 30;
        state.realDownloaded = 30;
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(2, updateTimes.get());
        assertEquals(100, states[0].total);
        assertEquals(30, states[0].realDownloaded);
        assertEquals(DownloadManager.STATUS_FAILED, states[0].status);
    }

    @Test
    public void testDownloadFileDelete() {
        DownloadState[] states = new DownloadState[1];
        assertEquals(0, appDownloadManager.listenerSize(config.getKey()));
        //noinspection ResultOfMethodCallIgnored
        appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> {
                    updateTimes.incrementAndGet();
                    states[0] = state;
                });
        appDownloadManager.startDownloadIfNeed(config);
        assertEquals(1, updateTimes.get());

        //Download complete
        DownloadState state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_SUCCESSFUL;
        state.total = 100;
        state.downloaded = 100;
        state.realDownloaded = 100;
        state.localUrl = makeFileAndGetPath(context, config.getDirType(),
                config.getDownloadFileName());
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(2, updateTimes.get());
        assertEquals(100, states[0].total);
        assertEquals(100, states[0].realDownloaded);
        assertEquals(DownloadManager.STATUS_SUCCESSFUL, states[0].status);
        assertTrue(states[0].isDone());

        //Delete file
        deleteFile(context, state.localUrl);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(3, updateTimes.get());
        assertFalse(states[0].isDone());
        assertEquals(100, states[0].total);
        assertEquals(0, states[0].realDownloaded);
        assertEquals(0, states[0].downloaded);
    }

    @Test
    public void testNotifyTimes() {
        DownloadState[] states = new DownloadState[1];
        assertEquals(0, appDownloadManager.listenerSize(config.getKey()));
        //noinspection ResultOfMethodCallIgnored
        appDownloadManager.subscribeDownloadState(config)
                .subscribe(state -> {
                    updateTimes.incrementAndGet();
                    states[0] = state;
                });
        appDownloadManager.startDownloadIfNeed(config);
        assertEquals(1, updateTimes.get());

        DownloadState state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_RUNNING;
        state.total = 100;
        state.downloaded = 30;
        state.realDownloaded = 30;
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(2, updateTimes.get());

        appDownloadManager.refreshState(state.key, false);
        assertEquals(2, updateTimes.get());

        state = copyDownloadState(states[0]);
        state.downloaded = 31;
        state.realDownloaded = 31;
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(3, updateTimes.get());

        state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_PAUSED;
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(4, updateTimes.get());

        state = copyDownloadState(states[0]);
        state.status = DownloadManager.STATUS_SUCCESSFUL;
        state.total = 100;
        state.downloaded = 100;
        state.realDownloaded = 100;
        state.localUrl = makeFileAndGetPath(context, config.getDirType(),
                config.getDownloadFileName());
        systemDownloadImpl.udapteDownload(state);
        appDownloadManager.refreshState(state.key, false);
        assertEquals(5, updateTimes.get());

        appDownloadManager.refreshState(state.key, false);
        assertEquals(5, updateTimes.get());
    }

    @After
    public void tearDown() {
        appDownloadManager.deleteDownload(config);
    }

}
