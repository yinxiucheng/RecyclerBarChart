package com.xiaomi.wearable.update;

import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;

public class RemoteTestCheckUpdater implements ICheckUpdater {

    private final ArrayMap<String, AppUpdateInfo> mStateMap = new ArrayMap<>();

    public void setInfo(AppUpdateInfo info) {
        mStateMap.put(KeyUtils.getUpdateInfoKey(info.versionName, info.versionCode), info);
    }

    @NonNull
    @Override
    public AppUpdateInfo checkUpgrade(String versionName, int versionCode) {
        AppUpdateInfo info = mStateMap.get(KeyUtils.getUpdateInfoKey(versionName, versionCode));
        if (info == null) {
            info = new AppUpdateInfo(-1, versionName, versionCode, null, null);
        }
        return info;
    }
}
