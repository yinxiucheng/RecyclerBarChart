package com.xiaomi.wearable.download.statehandler;

import android.content.Context;

import com.xiaomi.wearable.download.DownloadState;
import com.xiaomi.wearable.util.SharePreferenceUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

import java.util.Objects;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class StateHandlerTest {

    private StateHandler handler;
    private MemoryStateHandler memoryStateHandler;
    private DiskStateHandler diskStateHandler;

    @Before
    public void setup() {
        SharePreferenceUtil.getInstance().setPreferences(
                RuntimeEnvironment.application
                        .getSharedPreferences("123", Context.MODE_PRIVATE));
        memoryStateHandler = new MemoryStateHandler();
        diskStateHandler = new DiskStateHandler();
        handler = new StateHandler(memoryStateHandler, diskStateHandler);
    }

    @Test
    public void testGet() {
        String key = "123";
        assertNull(memoryStateHandler.getDownloadState(key));
        assertNull(diskStateHandler.getDownloadState(key));
        assertNull(handler.getDownloadState(key));

        diskStateHandler.updateDownloadState(new DownloadState(key, 10));
        DownloadState state = handler.getDownloadState(key);
        assertNotNull(state);
        assertEquals(10, state.downloadId);
        assertEquals(10, Objects.requireNonNull(memoryStateHandler.getDownloadState(key)).downloadId);
    }

    @Test
    public void testDelete() {
        testGet();
        handler.deleteState("123");
        assertNull(handler.getDownloadState("123"));
        assertNull(memoryStateHandler.getDownloadState("123"));
        assertNull(diskStateHandler.getDownloadState("123"));
    }

}
