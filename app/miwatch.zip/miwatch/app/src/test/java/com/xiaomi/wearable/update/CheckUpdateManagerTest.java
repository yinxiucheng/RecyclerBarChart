package com.xiaomi.wearable.update;

import android.content.Context;

import com.xiaomi.wearable.util.SharePreferenceUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.disposables.Disposable;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class CheckUpdateManagerTest {

    private CheckUpdateManager manager;
    private LocalCheckUpdater localCheckUpdater;
    private RemoteTestCheckUpdater remoteCheckUpdater;

    @Before
    public void setup() {
        SharePreferenceUtil.getInstance().setPreferences(
                RuntimeEnvironment.application
                        .getSharedPreferences("123", Context.MODE_PRIVATE));
        localCheckUpdater = new LocalCheckUpdater();
        remoteCheckUpdater = new RemoteTestCheckUpdater();
        manager = new CheckUpdateManager(localCheckUpdater, remoteCheckUpdater);
    }

    @Test
    public void testNoUpdate() {
        AppUpdateInfo info = localCheckUpdater.checkUpgrade("1", 1);
        assertNotNull(info);
        assertFalse("Update status false", info.shouldUpdate());
        assertFalse(info.shouldForceUpdate());

        info = remoteCheckUpdater.checkUpgrade("1", 1);
        assertNotNull(info);
        assertFalse("Update status false", info.shouldUpdate());
        assertFalse(info.shouldForceUpdate());

        info = manager.checkUpdate("1", 1, false).blockingFirst();
        assertNotNull(info);
        assertFalse("Update status false", info.shouldUpdate());
        assertFalse(info.shouldForceUpdate());
    }

    @Test
    public void testHasUpdate() {
        remoteCheckUpdater.setInfo(
                new AppUpdateInfo(0, "1", 1, "url", "log"));
        assertFalse(localCheckUpdater.checkUpgrade("1", 1).shouldUpdate());
        assertFalse(manager.checkUpdate("1", 1, true)
                .blockingFirst().shouldUpdate());

        AppUpdateInfo info = manager.checkUpdate("1", 1, false).blockingFirst();
        assertNotNull(info);
        assertTrue(info.shouldUpdate());
        assertEquals("url", info.downloadUrl);
        assertEquals("log", info.changeLog);
        assertEquals("1", info.versionName);
        assertEquals(1, info.versionCode);

        assertTrue("Should has update",
                localCheckUpdater.checkUpgrade("1", 1).shouldUpdate());
    }

    @Test
    public void testHasNewUpdate() {
        remoteCheckUpdater.setInfo(
                new AppUpdateInfo(0, "1", 1, "url", "log"));
        Disposable disposable = manager.checkUpdate("1", 1, false)
                .subscribe(appUpdateInfo -> assertTrue(appUpdateInfo.shouldUpdate()));
        assertTrue(localCheckUpdater.checkUpgrade("1", 1).shouldUpdate());

        remoteCheckUpdater.setInfo(
                new AppUpdateInfo(0, "2", 2, "url", "log"));
        assertFalse(localCheckUpdater.checkUpgrade("2", 2).shouldUpdate());
        assertTrue(remoteCheckUpdater.checkUpgrade("2", 2).shouldUpdate());
        disposable.dispose();
        disposable = manager.checkUpdate("2", 2, false)
                .subscribe(appUpdateInfo -> assertTrue(appUpdateInfo.shouldUpdate()));
        assertTrue(localCheckUpdater.checkUpgrade("2", 2).shouldUpdate());
        disposable.dispose();
        disposable = manager.checkUpdate("3", 2, false)
                .subscribe(appUpdateInfo -> assertFalse(appUpdateInfo.shouldUpdate()));
        disposable.dispose();
    }

    @Test
    public void testObserver() {
        AppUpdateInfo[] testInfo = new AppUpdateInfo[1];
        testInfo[0] = new AppUpdateInfo(-1, "1", 1, null, null);
        AtomicInteger updateCount = new AtomicInteger();
        Disposable d1 = manager.checkUpdate("1", 1, false)
                .subscribe(appUpdateInfo -> {
                    assertEquals(testInfo[0].shouldUpdate(), appUpdateInfo.shouldUpdate());
                    assertEquals(testInfo[0].versionName, appUpdateInfo.versionName);
                    assertEquals(testInfo[0].versionCode, appUpdateInfo.versionCode);
                    updateCount.incrementAndGet();
                });
        assertEquals(1, updateCount.get());

        remoteCheckUpdater.setInfo(
                new AppUpdateInfo(0, "1", 1, "url", "log"));
        testInfo[0] = new AppUpdateInfo(0, "1", 1, "url", "log");
        Disposable d2 = manager.checkUpdate("1", 1, false)
                .subscribe(appUpdateInfo -> {
                    assertEquals(testInfo[0].shouldUpdate(), appUpdateInfo.shouldUpdate());
                    assertEquals(testInfo[0].versionName, appUpdateInfo.versionName);
                    assertEquals(testInfo[0].versionCode, appUpdateInfo.versionCode);
                    updateCount.incrementAndGet();
                });
        assertEquals(3, updateCount.get());

        d1.dispose();
        d2.dispose();

        Disposable d3 = manager.checkUpdate("1", 1, false)
                .subscribe(appUpdateInfo -> updateCount.incrementAndGet());
        assertEquals(4, updateCount.get());

        d3.dispose();

        //noinspection ResultOfMethodCallIgnored
        manager.checkUpdate("1", 1, false)
                .subscribe(appUpdateInfo -> updateCount.incrementAndGet());
        assertEquals(5, updateCount.get());
        assertSame(1, manager.listenerSize());
    }
}
