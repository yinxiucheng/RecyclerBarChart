package com.xiaomi.wearable.download;

import android.support.annotation.NonNull;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class SystemDownloadTestImpl implements ISystemDownloadManager {
    private final HashMap<Long, DownloadState> mDownloadMap = new HashMap<>();
    private final AtomicInteger mDownloadInteger = new AtomicInteger();

    @Override
    public void remove(long... ids) {
        for (long id : ids) {
            mDownloadMap.remove(id);
        }
    }

    @Override
    public long downloadFile(@NonNull DownloadConfig config) {
        long downloadId = mDownloadInteger.incrementAndGet();
        mDownloadMap.put(downloadId, new DownloadState(config.getKey(), downloadId));
        return downloadId;
    }

    @Override
    public DownloadState query(@NonNull DownloadState state) {
        return mDownloadMap.get(state.downloadId);
    }

    void udapteDownload(DownloadState state) {
        mDownloadMap.put(state.downloadId, state);
    }

    boolean containsState(DownloadState state) {
        return mDownloadMap.containsKey(state.downloadId);
    }

    int getCount() {
        return mDownloadInteger.get();
    }
}
