package com.today.step.lib;

import android.content.BroadcastReceiver;

/**
 * 通知栏点击通知
 * Created by jiahongfei on 2017/10/19.
 */

public abstract class BaseClickBroadcast extends BroadcastReceiver {

}
