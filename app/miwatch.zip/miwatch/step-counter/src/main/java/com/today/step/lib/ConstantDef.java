package com.today.step.lib;

/**
 * @author :  jiahongfei
 * @email : jiahongfeinew@163.com
 * @date : 2018/12/25
 * @desc : 计步公共常量
 */
public class ConstantDef {

    /**
     * 打印JLogger日志
     */
    public static final int HANDLER_WHAT_TEST_JLOGGER = 0;
    /**
     * 打印JLogger日志时间
     */
    public static final int WHAT_TEST_JLOGGER_DURATION = 1000*60*5;//5分钟

}
