package com.xiaomi.common.util;

/**
 * @author yxc
 * @date 2019/3/15
 */

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;
import android.text.style.ReplacementSpan;

/**
 * 使TextView中不同大小字体顶部对齐
 */
public class CenterSpan extends ReplacementSpan {

    private float fontSizePx;    //px

    public CenterSpan(float fontSizePx) {
        this.fontSizePx = fontSizePx;
    }

    @Override
    public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt fm) {
        text = text.subSequence(start, end);
        Paint p = getCustomTextPaint(paint);
        return (int) p.measureText(text.toString());
    }

    @Override
    public void draw(Canvas canvas, CharSequence text, int start, int end, float x, int top, int y, int bottom, Paint paint) {
        text = text.subSequence(start, end);
        Paint p = getCustomTextPaint(paint);
        Paint.FontMetricsInt fm = p.getFontMetricsInt();
        int height = ((y + fm.descent + y + fm.ascent) - (bottom + top)) - DisplayUtil.dip2px(1);
        // 此处重新计算y坐标，使字体顶部对齐
        canvas.drawText(text.toString(), x, y - height, p);
//        canvas.drawText(text.toString(), x, y, p);
    }

    private TextPaint getCustomTextPaint(Paint srcPaint) {
        TextPaint paint = new TextPaint(srcPaint);
        paint.setTextSize(fontSizePx);   //设定字体大小, sp转换为px
        return paint;
    }
}

