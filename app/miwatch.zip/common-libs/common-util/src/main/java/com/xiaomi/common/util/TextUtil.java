package com.xiaomi.common.util;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

/**
 * @author yxc
 * @since 2019/3/7
 */
public class TextUtil {

    public static SpannableStringBuilder getSpannableStr(Context context, int texSize, String parentStr, String... strArgs) {
        return getSpannableStr(context, texSize, true, parentStr, strArgs);
    }

    public static SpannableStringBuilder getSpannableStr(Context context, int texSize, boolean isBold, String parentStr, String... strArgs) {
        SpannableStringBuilder spannable = new SpannableStringBuilder(parentStr);
        StyleSpan styleSpan = new StyleSpan(Typeface.NORMAL);//粗体
        for (String subStr : strArgs) {
            AbsoluteSizeSpan sizeSpan = new AbsoluteSizeSpan(DisplayUtil.sp2px(context, texSize));
            int subBeginIndex = parentStr.indexOf(subStr);
            int subEndIndex = subBeginIndex + subStr.length();
            spannable.setSpan(sizeSpan, subBeginIndex, subEndIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (isBold) {
                styleSpan = new StyleSpan(Typeface.BOLD);
            }
            spannable.setSpan(styleSpan, subBeginIndex, subEndIndex, Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
        }
        return spannable;
    }

    public static SpannableStringBuilder getSpannableStr(Context context, int texSize, ForegroundColorSpan colorSpan, String parentStr, String... strArgs) {
        return getSpannableStr(context, texSize, true, colorSpan, parentStr, strArgs);
    }

    public static SpannableStringBuilder getSpannableStr(Context context, int texSize, boolean isBold, ForegroundColorSpan colorSpan, String parentStr, String... strArgs) {
        SpannableStringBuilder spannable = new SpannableStringBuilder(parentStr);
        StyleSpan styleSpan = new StyleSpan(Typeface.NORMAL);//粗体
        for (String subStr : strArgs) {
            AbsoluteSizeSpan sizeSpan = new AbsoluteSizeSpan(DisplayUtil.sp2px(context, texSize));
            int subBeginIndex = parentStr.indexOf(subStr);
            int subEndIndex = subBeginIndex + subStr.length();
            spannable.setSpan(sizeSpan, subBeginIndex, subEndIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (isBold) {
                styleSpan = new StyleSpan(Typeface.BOLD);
            }
            spannable.setSpan(styleSpan, subBeginIndex, subEndIndex, Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
            spannable.setSpan(colorSpan, subBeginIndex, subEndIndex, Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
        }
        return spannable;
    }


    public static float getTxtHeight1(Paint paint) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return fontMetrics.bottom - fontMetrics.top;
    }

    @SuppressWarnings("unused")
    public static float getTxtHeight2(Paint paint) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return fontMetrics.descent - fontMetrics.ascent;
    }

}
