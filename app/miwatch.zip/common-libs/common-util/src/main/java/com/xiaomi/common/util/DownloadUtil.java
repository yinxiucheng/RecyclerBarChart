package com.xiaomi.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadUtil {

    public static String download(final String httpUrl) throws Exception {
        HttpURLConnection connection = getHealthyConnection(httpUrl);

        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()), 1024);
        String line;
        try {
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } finally {
            br.close();
        }
        return sb.toString();
    }

    public static void downloadToFile(final String httpUrl, final File file) throws Exception {
        HttpURLConnection connection = getHealthyConnection(httpUrl);
        InputStream inputStream = connection.getInputStream();
        FileOutputStream outputStream = new FileOutputStream(file);

        byte[] buffer = new byte[8 * 1024];
        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, len);
        }
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    private static HttpURLConnection getHealthyConnection(final String httpUrl) throws IOException {
        URL url = new URL(httpUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(15000);
        connection.setUseCaches(false);
        connection.setRequestMethod("GET");
        connection.connect();

        int status = connection.getResponseCode();
        if (status != 200) {
            throw new IOException("http request failed with status code " + status);
        }

        return connection;
    }

}
