package com.xiaomi.common.crypt;

import android.text.TextUtils;

import com.xiaomi.common.crypt.rc4coder.Coder;
import com.xiaomi.common.crypt.rc4coder.RC4DropCoder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class CloudUtil {

    public static String generateNonce(long timeDiff) {
        return CloudCoder.generateNonce(timeDiff);
    }

    public static Map<String, String> encryptParams(String method, String path, Map<String, String> params,
                                                    String nonce, String ssecurity) throws Exception {
        Map<String, String> encryptedParams = new HashMap<>();
        Map<String, String> plainParamMap = new TreeMap<>();
        Map<String, String> encryptedMap = new TreeMap<>();

        if (params != null) {
            for (Map.Entry<String, String> param : params.entrySet()) {
                String key = param.getKey();
                String value = param.getValue();
                if (!TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                    plainParamMap.put(key, value);
                }
            }
        }
        byte[] bytes = concatBytes(Coder.decryptBASE64(ssecurity), Coder.decryptBASE64(nonce));
        String sessionSecurity = Coder.encryptBASE64(Coder.sha256Hash(bytes));
        String rc4Hash = CloudCoder.generateSignature(method, path, plainParamMap, sessionSecurity);
        plainParamMap.put("rc4_hash__", rc4Hash);

        RC4DropCoder coder = new RC4DropCoder(sessionSecurity);
        Set<Map.Entry<String, String>> entries = plainParamMap.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            String encryptedValue = coder.encrypt(entry.getValue());
            encryptedMap.put(entry.getKey(), encryptedValue);
            encryptedParams.put(entry.getKey(), encryptedValue);
        }

        String signature = CloudCoder.generateSignature(method, path, encryptedMap, sessionSecurity);
        encryptedParams.put("signature", signature);
        encryptedParams.put("_nonce", nonce);
        return encryptedParams;
    }

    public static Map<String, String> encryptParams2(String path, Map<String, String> params,
                                                     String nonce, String ssecurity) throws Exception {
        //netRequest.getHeaders().add(new KeyValuePair("X-XIAOMI-PROTOCAL-FLAG-CLI", "PROTOCAL-HTTP2"));

        Map<String, String> encryptedParams = new HashMap<>();
        TreeMap<String, String> plainParamMap = new TreeMap<>();

        if (params != null) {
            for (Map.Entry<String, String> param : params.entrySet()) {
                String key = param.getKey();
                String value = param.getValue();
                if (!TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
                    plainParamMap.put(key, value);
                }
            }
        }
        byte[] bytes = concatBytes(Coder.decryptBASE64(ssecurity), Coder.decryptBASE64(nonce));
        String sessionSecurity = Coder.encryptBASE64(Coder.sha256Hash(bytes));

        List<String> segments = new ArrayList<>();
        if (path != null) {
            segments.add(path);
        }
        segments.add(sessionSecurity);
        segments.add(nonce);
        if (!plainParamMap.isEmpty()) {
            for (Map.Entry<String, String> entry : plainParamMap.entrySet()) {
                segments.add(String.format("%s=%s", entry.getKey(), entry.getValue()));
            }
        } else {
            segments.add("data=");
        }

        boolean first = true;
        StringBuilder sb = new StringBuilder();
        for (String segment : segments) {
            if (!first) {
                sb.append('&');
            }
            sb.append(segment);
            first = false;
        }

        String signature = getSignature(sb.toString(), sessionSecurity);
        encryptedParams.put("signature", signature);
        encryptedParams.put("_nonce", nonce);
        if (params != null) {
            encryptedParams.putAll(params);
        }
        return encryptedParams;
    }

    private static String getSignature(String message, String secret) throws Exception {
        byte[] bytes = HMAC.sha256Hmac(Coder.decryptBASE64(secret), message);
        return Coder.encryptBASE64(bytes);
    }

    public static String decryptResponse(String cipher, String nonce, String ssecurity) throws Exception {
        byte[] bytes = concatBytes(Coder.decryptBASE64(ssecurity), Coder.decryptBASE64(nonce));
        String sessionSecurity = Coder.encryptBASE64(Coder.sha256Hash(bytes));
        RC4DropCoder coderDecrypt = new RC4DropCoder(sessionSecurity);
        return coderDecrypt.decrypt(cipher);
    }

    private static byte[] concatBytes(byte[] a, byte[] b) {
        byte[] c = new byte[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
    }

}
