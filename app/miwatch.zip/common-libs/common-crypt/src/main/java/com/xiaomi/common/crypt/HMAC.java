package com.xiaomi.common.crypt;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class HMAC {

    public static byte[] sha256Hmac(byte[] key, String message) throws Exception {
        final String algorithm = "HmacSHA256";
        Mac mac = Mac.getInstance(algorithm);
        SecretKeySpec secretKey = new SecretKeySpec(key, algorithm);
        mac.init(secretKey);
        return mac.doFinal(message.getBytes());
    }

    public static String sha256HmacHexString(byte[] key, String message) throws Exception {
        byte[] bytes = sha256Hmac(key, message);
        return byteArrayToHexString(bytes);
    }

    public static String byteArrayToHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte element : bytes) {
            int v = element & 0xff;
            if (v < 16) {
                sb.append('0');
            }
            sb.append(Integer.toHexString(v));
        }
        return sb.toString();
    }

}
