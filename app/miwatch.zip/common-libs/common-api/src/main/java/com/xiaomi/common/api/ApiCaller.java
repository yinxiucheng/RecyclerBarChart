package com.xiaomi.common.api;

import android.support.annotation.RestrictTo;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public interface ApiCaller<S> {

    <M> ApiRequest<M> call(final ApiProvider<M, S> apiProvider, ApiRequest.Listener<M> listener);

    void retry(ApiRequest apiRequest);

    void cancel(ApiRequest apiRequest);

}
