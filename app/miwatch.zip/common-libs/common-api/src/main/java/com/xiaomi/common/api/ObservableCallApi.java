package com.xiaomi.common.api;

import android.support.annotation.NonNull;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ObservableCallApi<M> extends Observable<M> implements Disposable {

    private final CallEntry<M> mCallEntry;
    private ApiRequest<M> mApiRequest;

    public ObservableCallApi(@NonNull final CallEntry<M> callEntry) {
        mCallEntry = callEntry;
    }

    @Override
    protected void subscribeActual(final Observer<? super M> observer) {
        observer.onSubscribe(this);
        mApiRequest = mCallEntry.call(new ApiRequest.Listener<M>() {
            @Override
            public void onSuccess(M response) {
                if (!isDisposed()) {
                    observer.onNext(response);
                    observer.onComplete();
                }
            }

            @Override
            public void onFailure(ApiError apiError) {
                if (!isDisposed()) {
                    observer.onError(new ApiException(apiError));
                }
            }
        });
    }

    @Override
    public void dispose() {
        mApiRequest.cancel();
    }

    @Override
    public boolean isDisposed() {
        return mApiRequest.isCanceled();
    }

}
