package com.xiaomi.common.api;

import android.support.annotation.NonNull;

import io.reactivex.Observable;

public interface TokenFetcher<T> {

    Observable<T> fetch(@NonNull final String id, final boolean invalidate);

}
