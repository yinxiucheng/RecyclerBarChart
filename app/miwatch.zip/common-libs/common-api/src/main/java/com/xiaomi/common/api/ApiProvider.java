package com.xiaomi.common.api;

import android.support.annotation.RestrictTo;

import io.reactivex.Observable;
import retrofit2.Response;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public interface ApiProvider<M, S> {

    Observable<Response<M>> observable(S service);

}
