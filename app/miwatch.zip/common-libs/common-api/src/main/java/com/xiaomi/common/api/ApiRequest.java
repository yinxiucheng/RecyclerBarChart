package com.xiaomi.common.api;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import retrofit2.Response;

public class ApiRequest<M> {

    public interface Listener<M> {
        void onSuccess(M response);

        void onFailure(ApiError apiError);
    }

    private static final int MAX_RETRY_TIMES = 2;

    private final ApiCaller mApiCaller;
    private Listener<M> mListener;

    private Observable<Response<M>> mObservable;
    private Disposable mDisposable;
    private volatile boolean mCanceled;

    private int mRetryTimes = 0;
    private boolean mRetrying = false;

    ApiRequest(ApiCaller apiCaller, Listener<M> listener) {
        mApiCaller = apiCaller;
        mListener = listener;
    }

    void setObservable(Observable<Response<M>> observable) {
        if (mObservable != null) {
            throw new IllegalStateException("ApiRequest already has an observable.");
        }
        mObservable = observable;
    }

    public synchronized void cancel() {
        if (!mCanceled) {
            mCanceled = true;
            if (mDisposable != null && !mDisposable.isDisposed()) {
                mDisposable.dispose();
                mDisposable = null;
            }
            if (mRetrying) {
                mRetryTimes = 0;
                mRetrying = false;
                mApiCaller.cancel(this);
            }
        }
    }

    public synchronized boolean isCanceled() {
        return mCanceled;
    }

    synchronized void subscribe() {
        if (mObservable == null) {
            throw new IllegalStateException("ApiRequest has not an observable.");
        }
        if (mCanceled) {
            return;
        }

        mDisposable = mObservable.filter(new Predicate<Response<M>>() {
            @Override
            public boolean test(Response<M> response) throws Exception {
                synchronized (ApiRequest.this) {
                    if (mCanceled) {
                        return false;
                    }
                }

                if (response.code() == 401) {
                    if (mRetryTimes >= MAX_RETRY_TIMES) {
                        error(ApiError.TOKEN_INVALID);
                    } else {
                        synchronized (ApiRequest.this) {
                            mRetryTimes++;
                            mRetrying = true;
                        }
                        mApiCaller.retry(ApiRequest.this);
                    }
                    return false;
                }

                synchronized (ApiRequest.this) {
                    mRetryTimes = 0;
                    mRetrying = false;
                }
                return true;
            }
        })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Response<M>>() {
                    @Override
                    public void accept(Response<M> response) throws Exception {
                        synchronized (ApiRequest.this) {
                            if (mCanceled) {
                                return;
                            }
                        }

                        if (mListener != null) {
                            if (response.isSuccessful()) {
                                mListener.onSuccess(response.body());
                            } else {
                                int httpCode = response.code();
                                if (httpCode >= 400 && httpCode < 500) {
                                    mListener.onFailure(ApiError.HTTP_CODE_4XX);
                                } else if (httpCode >= 500) {
                                    mListener.onFailure(ApiError.HTTP_CODE_5XX);
                                } else {
                                    mListener.onFailure(ApiError.HTTP_CODE_OTHER);
                                }
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        synchronized (ApiRequest.this) {
                            if (mCanceled) {
                                return;
                            }
                            mRetryTimes = 0;
                            mRetrying = false;
                        }

                        if (mListener != null) {
                            mListener.onFailure(ApiError.HTTP_ENGINE_EXCEPTION);
                        }
                    }
                });
    }

    void error(ApiError apiError) {
        synchronized (ApiRequest.this) {
            if (mCanceled) {
                return;
            }
            mRetryTimes = 0;
            mRetrying = false;
        }

        if (mListener != null) {
            Observable.just(apiError)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<ApiError>() {
                        @Override
                        public void onSubscribe(Disposable d) {
                        }

                        @Override
                        public void onNext(ApiError apiError) {
                            mListener.onFailure(apiError);
                        }

                        @Override
                        public void onError(Throwable e) {
                        }

                        @Override
                        public void onComplete() {
                        }
                    });
        }
    }

}
