package com.xiaomi.common.api;

public final class ApiException extends Exception {

    private final ApiError mApiError;

    ApiException(ApiError apiError) {
        super(apiError.getMessage());
        mApiError = apiError;
    }

    public int getErrorCode() {
        return mApiError.getCode();
    }

}
