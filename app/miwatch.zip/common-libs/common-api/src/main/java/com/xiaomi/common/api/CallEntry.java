package com.xiaomi.common.api;

public interface CallEntry<M> {

    ApiRequest<M> call(ApiRequest.Listener<M> listener);

}
