package com.xiaomi.common.api;

import android.util.Log;

public interface ApiLogger {

    void i(String message);

    void w(String message);

    void e(String message);

    ApiLogger DEFAULT = new ApiLogger() {
        private static final String TAG = "API";

        @Override
        public void i(String message) {
            Log.i(TAG, message);
        }

        @Override
        public void w(String message) {
            Log.w(TAG, message);
        }

        @Override
        public void e(String message) {
            Log.e(TAG, message);
        }
    };

}
