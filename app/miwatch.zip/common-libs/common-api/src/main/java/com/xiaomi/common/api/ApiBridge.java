package com.xiaomi.common.api;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Interceptor;

abstract public class ApiBridge<T, S> implements TokenFetcher<T> {

    protected final Context mContext;
    protected final ApiLogger mApiLogger;
    protected BaseApiCaller<T, S> mApiCaller;

    protected ApiBridge(Context context,
                        ApiLogger apiLogger) {
        mContext = context.getApplicationContext();
        mApiLogger = apiLogger != null ? apiLogger : ApiLogger.DEFAULT;
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY)
    public final <M> ApiRequest<M> callApi(final ApiProvider<M, S> apiProvider, ApiRequest.Listener<M> listener) {
        if (mApiCaller == null) {
            throw new IllegalArgumentException("api caller has not initialized");
        }
        return mApiCaller.call(apiProvider, listener);
    }

    public final void reset() {
        if (mApiCaller != null) {
            mApiCaller.reset();
        }
    }

    public static class Builder {
        protected final Context context;
        protected List<Interceptor> interceptors = new ArrayList<>();
        protected List<Interceptor> networkInterceptors = new ArrayList<>();
        protected ApiLogger apiLogger;

        public Builder(@NonNull Context context) {
            this.context = context.getApplicationContext();
        }

        public Builder addInterceptor(@NonNull Interceptor interceptor) {
            this.interceptors.add(interceptor);
            return this;
        }

        public Builder addNetworkInterceptor(@NonNull Interceptor interceptor) {
            this.networkInterceptors.add(interceptor);
            return this;
        }

        public Builder apiLogger(@NonNull ApiLogger apiLogger) {
            this.apiLogger = apiLogger;
            return this;
        }
    }

}
