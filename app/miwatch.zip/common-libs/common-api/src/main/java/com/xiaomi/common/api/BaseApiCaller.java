package com.xiaomi.common.api;

import android.content.Context;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.xiaomi.common.api.interceptor.UAInterceptor;

import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class BaseApiCaller<T, S> implements CookieJar, ApiCaller<S> {

    private enum State {
        Initialized,
        Valid,
        Refreshing,
        LoginRequired
    }

    private static class TokenStatus {
        private State state;
        private long lastRefreshTimestamp;

        private TokenStatus() {
            state = State.Initialized;
            lastRefreshTimestamp = 0L;
        }
    }

    private final Context mContext;
    private final String mId;
    protected final ApiLogger mApiLogger;
    private final Scheduler mDispatcherScheduler;
    private S mApiService;

    private final TokenFetcher<T> mTokenFetcher;
    private final TokenStatus mTokenStatus;
    private T mToken;
    private final Object mTokenLock = new Object();
    private Disposable mTokenDisposable;

    private List<ApiRequest> mPendingRequests = new ArrayList<>();
    private final Object mRequestLock = new Object();

    @SuppressWarnings("unchecked")
    public BaseApiCaller(@NonNull Context context,
                         @NonNull String id,
                         @NonNull String baseUrl,
                         @NonNull List<Interceptor> interceptors,
                         @NonNull List<Interceptor> networkInterceptors,
                         @NonNull ApiLogger apiLogger,
                         @NonNull TokenFetcher<T> tokenFetcher) {
        mContext = context;
        mId = id;
        mApiLogger = apiLogger;

        DispatcherThread dispatcherThread = new DispatcherThread(id);
        dispatcherThread.start();
        Looper looper = dispatcherThread.getLooper();
        mDispatcherScheduler = AndroidSchedulers.from(looper);

        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .addInterceptor(new UAInterceptor())
                .addInterceptor(new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
                    @Override
                    public void log(@NonNull String message) {
                        mApiLogger.i(message);
                    }
                }).setLevel(HttpLoggingInterceptor.Level.BODY));
        addInnerInterceptor(id, interceptors);
        for (Interceptor interceptor : interceptors) {
            builder.addInterceptor(interceptor);
        }
        addInnerNetworkInterceptor(id, networkInterceptors);
        for (Interceptor interceptor : networkInterceptors) {
            builder.addInterceptor(interceptor);
        }
        builder.cookieJar(this);

        Retrofit retrofit = new Retrofit.Builder()
                .client(builder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.createAsync())
                .baseUrl(baseUrl)
                .build();
        ParameterizedType type = (ParameterizedType) this.getClass().getGenericSuperclass();
        assert type != null;
        mApiService = retrofit.create((Class<S>) type.getActualTypeArguments()[1]);

        mTokenFetcher = tokenFetcher;
        mToken = getCachedToken(context);
        mTokenStatus = new TokenStatus();
        if (mToken != null) {
            mTokenStatus.state = State.Valid;
        }
    }

    protected void addInnerInterceptor(@NonNull String id, @NonNull List<Interceptor> interceptors) {
    }

    protected void addInnerNetworkInterceptor(@NonNull String id, @NonNull List<Interceptor> interceptors) {
    }

    @Nullable
    protected T getToken() {
        synchronized (mTokenLock) {
            return mToken;
        }
    }

    @Nullable
    protected T getCachedToken(@NonNull Context context) {
        return null;
    }

    protected void onTokenRefreshed(@NonNull Context context, @NonNull T token) {
    }

    void reset() {
        if (mTokenDisposable != null && !mTokenDisposable.isDisposed()) {
            mTokenDisposable.dispose();
            mTokenDisposable = null;
        }
        Observable.create(new ObservableOnSubscribe<Object>() {
            @Override
            public void subscribe(ObservableEmitter<Object> emitter) throws Exception {
                synchronized (mTokenLock) {
                    mToken = null;
                }
                synchronized (mRequestLock) {
                    mPendingRequests.clear();
                }
                resetAccessTokenStatus();
                emitter.onNext(new Object());
                emitter.onComplete();
            }
        }).subscribeOn(mDispatcherScheduler).subscribe();
    }

    @Override
    public void saveFromResponse(@NonNull HttpUrl url, @NonNull List<Cookie> cookies) {
    }

    @NonNull
    @Override
    public List<Cookie> loadForRequest(@NonNull HttpUrl url) {
        return Collections.emptyList();
    }

    @Override
    public <M> ApiRequest<M> call(final ApiProvider<M, S> apiProvider, ApiRequest.Listener<M> listener) {
        final ApiRequest<M> apiRequest = new ApiRequest<>(this, listener);
        Observable.create(new ObservableOnSubscribe<Object>() {
            @Override
            public void subscribe(ObservableEmitter<Object> emitter) throws Exception {
                apiRequest.setObservable(apiProvider.observable(mApiService)
                        .subscribeOn(mDispatcherScheduler)
                        .observeOn(mDispatcherScheduler));
                if (!apiRequest.isCanceled()) {
                    if (mToken != null) {
                        apiRequest.subscribe();
                    } else {
                        synchronized (mRequestLock) {
                            mPendingRequests.add(apiRequest);
                        }
                        refreshToken(false);
                    }
                }
                emitter.onNext(new Object());
                emitter.onComplete();
            }
        }).subscribeOn(mDispatcherScheduler).subscribe();
        return apiRequest;
    }

    @Override
    public void retry(ApiRequest apiRequest) {
        if (mTokenStatus.state == State.Initialized
                || mTokenStatus.state == State.Valid) {
            long timeGap = Math.abs(System.currentTimeMillis() - mTokenStatus.lastRefreshTimestamp);
            if (TimeUnit.MILLISECONDS.toSeconds(timeGap) > 20) {
                synchronized (mRequestLock) {
                    mPendingRequests.add(apiRequest);
                }
                refreshToken(true);
            } else {
                executeRequest(apiRequest);
            }
        } else if (mTokenStatus.state == State.Refreshing) {
            synchronized (mRequestLock) {
                mPendingRequests.add(apiRequest);
            }
        } else {
            abandonRequest(apiRequest);
        }
    }

    @Override
    public void cancel(ApiRequest apiRequest) {
        synchronized (mRequestLock) {
            mPendingRequests.remove(apiRequest);
        }
    }

    private void refreshToken(boolean invalidate) {
        updateAccessTokenStatus(State.Refreshing);
        mTokenDisposable = mTokenFetcher.fetch(mId, invalidate)
                .subscribeOn(Schedulers.newThread())
                .observeOn(mDispatcherScheduler)
                .subscribe(new Consumer<T>() {
                    @Override
                    public void accept(T token) throws Exception {
                        synchronized (mTokenLock) {
                            mToken = token;
                        }
                        onTokenRefreshed(mContext, token);
                        updateAccessTokenStatus(State.Valid);
                        executePendingRequests();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable e) throws Exception {
                        updateAccessTokenStatus(State.LoginRequired);
                        abandonPendingRequests();
                    }
                });
    }

    private void updateAccessTokenStatus(State state) {
        mTokenStatus.state = state;
        mTokenStatus.lastRefreshTimestamp = System.currentTimeMillis();
    }

    private void resetAccessTokenStatus() {
        mTokenStatus.state = State.Initialized;
        mTokenStatus.lastRefreshTimestamp = 0L;
    }

    private void executePendingRequests() {
        synchronized (mRequestLock) {
            Iterator it = mPendingRequests.iterator();
            while (it.hasNext()) {
                ApiRequest apiRequest = (ApiRequest) it.next();
                executeRequest(apiRequest);
                it.remove();
            }
        }
    }

    private void abandonPendingRequests() {
        synchronized (mRequestLock) {
            Iterator it = mPendingRequests.iterator();
            while (it.hasNext()) {
                ApiRequest apiRequest = (ApiRequest) it.next();
                abandonRequest(apiRequest);
                it.remove();
            }
        }
    }

    private void executeRequest(ApiRequest apiRequest) {
        if (!apiRequest.isCanceled()) {
            apiRequest.subscribe();
        }
    }

    private void abandonRequest(ApiRequest apiRequest) {
        if (!apiRequest.isCanceled()) {
            apiRequest.error(ApiError.TOKEN_INSUFFICIENT);
        }
    }

    private static class DispatcherThread extends HandlerThread {
        DispatcherThread(final String id) {
            super("dispatcher-" + id, Process.THREAD_PRIORITY_BACKGROUND);
        }
    }

}
