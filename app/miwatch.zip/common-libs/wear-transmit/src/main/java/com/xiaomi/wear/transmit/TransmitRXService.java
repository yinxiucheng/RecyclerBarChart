package com.xiaomi.wear.transmit;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

import com.google.protobuf.nano.InvalidProtocolBufferNanoException;

public class TransmitRXService extends Service {

    private static final String TAG = "TransmitRXService";

    private Binder mBinder;
    private Handler mHandler;

    private TransmitManager mTransmitManager;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");

        mBinder = new TransmitRXBinder();
        mHandler = new Handler(Looper.getMainLooper());

        mTransmitManager = TransmitManager.getInstance();
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: action=" + intent.getAction());
        return Constants.ACTION_MESSAGE_RECEIVED.equals(intent.getAction()) ? mBinder : null;
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        super.onDestroy();
    }

    void onMessageReceived(final String path, final byte[] data, final ICallback callback) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    mTransmitManager.onMessageReceived(path, data);
                    try {
                        callback.onCallback(Constants.CODE_SUCCESS, null);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                } catch (InvalidProtocolBufferNanoException e) {
                    try {
                        callback.onCallback(Constants.CODE_PARSE_EXCEPTION, null);
                    } catch (RemoteException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
    }

    final class TransmitRXBinder extends ITransmit.Stub {
        private volatile int callingUid;

        private TransmitRXBinder() {
            callingUid = -1;
        }

        @Override
        public void sendMessage(String path, byte[] data, ICallback callback) throws RemoteException {
            boolean legal;
            int uid = Binder.getCallingUid();
            if (callingUid == uid) {
                legal = true;
            } else if (uidHasPackageName(uid, "com.xiaomi.wearable")) {
                callingUid = uid;
                legal = true;
            } else {
                legal = false;
            }

            if (legal) {
                onMessageReceived(path, data, callback);
            } else {
                Log.e(TAG, "Illegal app wants to bind");
                callback.onCallback(Constants.CODE_NO_PERMISSION, null);
            }
        }

        private boolean uidHasPackageName(int uid, String packageName) {
            PackageManager packageManager = getPackageManager();
            if (packageManager != null) {
                String[] packageNames = packageManager.getPackagesForUid(uid);
                if (packageName != null && packageNames != null) {
                    for (String name : packageNames) {
                        if (packageName.equals(name)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }

}
