package com.xiaomi.wear.transmit;

public class Constants {

    public static final int CODE_SUCCESS = 0;
    public static final int CODE_CONNECT_SERVICE_FAILED = 1;
    public static final int CODE_DEVICE_DISCONNECTED = 2;
    public static final int CODE_TRANSMIT_FAILED = 3;
    public static final int CODE_NO_PERMISSION = 4;
    public static final int CODE_PARSE_EXCEPTION = 5;

    public static final String ACTION_TRANSMIT = "com.xiaomi.wearable.transmit.BIND_LISTENER";
    public static final String ACTION_MESSAGE_RECEIVED = "com.xiaomi.wearable.transmit.MESSAGE_RECEIVED";

    public static final String MESSAGE_REQUEST_ID = "requestID";

}
