package com.xiaomi.wear.transmit;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class TransmitClient {

    private Context mContext;
    private Handler mWorkerHandler;
    private Handler mMainHandler;

    private ITransmit mTransmitter;
    private CountDownLatch mLatch;

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mTransmitter = ITransmit.Stub.asInterface(service);
            if (mLatch != null) {
                mLatch.countDown();
                mLatch = null;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mTransmitter = null;
        }
    };

    public TransmitClient(Context context) {
        mContext = context.getApplicationContext();
        HandlerThread handlerThread = new HandlerThread("TransmitClient");
        handlerThread.start();
        mWorkerHandler = new Handler(handlerThread.getLooper());
        mMainHandler = new Handler(Looper.getMainLooper());
    }

    public void sendMessage(String path, byte[] data, TransmitCallback callback) {
        mWorkerHandler.post(new MessageRunnable(path, data, callback));
    }

    private void bindServiceSync() {
        Intent intent = new Intent(Constants.ACTION_TRANSMIT);
        intent.setPackage("com.xiaomi.wearable");
        if (mContext.bindService(intent, mConnection, Context.BIND_AUTO_CREATE)) {
            try {
                mLatch = new CountDownLatch(1);
                mLatch.await(10, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private class MessageRunnable extends TransmitRunnable {
        MessageRunnable(String path, byte[] data, TransmitCallback callback) {
            super(path, data, callback);
        }

        @Override
        void transmit(String path, byte[] data, ICallback.Stub callback) throws RemoteException {
            mTransmitter.sendMessage(path, data, callback);
        }
    }

    abstract private class TransmitRunnable implements Runnable {
        final String path;
        final byte[] data;
        final TransmitCallback callback;

        TransmitRunnable(String path, byte[] data, TransmitCallback callback) {
            this.path = path;
            this.data = data;
            this.callback = callback;
        }

        @Override
        public void run() {
            if (mTransmitter == null) {
                bindServiceSync();
            }
            if (mTransmitter == null) {
                onConnectFailed();
            } else {
                try {
                    transmit(path, data, new ICallback.Stub() {
                        @Override
                        public void onCallback(int code, Bundle bundle) throws RemoteException {
                            onResponse(code, bundle);
                        }
                    });
                } catch (RemoteException e) {
                    onConnectFailed();
                }
            }
        }

        private void onConnectFailed() {
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onCallback(Constants.CODE_CONNECT_SERVICE_FAILED, null);
                    }
                });
            }
        }

        private void onResponse(final int code, final Bundle bundle) {
            if (callback != null) {
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onCallback(code, bundle);
                    }
                });
            }
        }

        abstract void transmit(String path, byte[] data, ICallback.Stub callback) throws RemoteException;
    }

}
