package com.xiaomi.wear.transmit;

import android.os.Bundle;

public interface TransmitCallback {

    void onCallback(int code, Bundle bundle);

}
