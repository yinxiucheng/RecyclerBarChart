package com.xiaomi.wear.transmit;

import com.google.protobuf.nano.InvalidProtocolBufferNanoException;

public interface TransmitConsumer {

    void onMessageReceived(String path, byte[] data) throws InvalidProtocolBufferNanoException;

}
