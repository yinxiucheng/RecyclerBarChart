package com.xiaomi.wear.transmit;

import android.annotation.SuppressLint;
import android.content.Context;

import com.google.protobuf.nano.InvalidProtocolBufferNanoException;

import java.util.ArrayList;
import java.util.List;

public class TransmitManager {

    @SuppressLint("StaticFieldLeak")
    private static TransmitManager sInstance;

    private Context mContext;
    private TransmitClient mTransmitClient;

    private List<TransmitConsumer> mConsumers = new ArrayList<>();

    private TransmitManager(Context context) {
        mContext = context.getApplicationContext();
    }

    public static TransmitManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException(
                    "No instance of TransmitManager was found, did you forget to call initialize()?");
        }
        return sInstance;
    }

    private void initialize() {
        mTransmitClient = new TransmitClient(mContext);
    }

    public static synchronized TransmitManager initialize(Context context) {
        if (sInstance == null) {
            sInstance = new TransmitManager(context.getApplicationContext());
            sInstance.initialize();
        }
        return sInstance;
    }

    public void addConsumer(TransmitConsumer consumer) {
        mConsumers.add(consumer);
    }

    public void removeConsumer(TransmitConsumer consumer) {
        mConsumers.remove(consumer);
    }

    public void sendMessage(String path, byte[] data, TransmitCallback callback) {
        mTransmitClient.sendMessage(path, data, callback);
    }

    void onMessageReceived(String path, byte[] data) throws InvalidProtocolBufferNanoException {
        for (TransmitConsumer consumer : mConsumers) {
            consumer.onMessageReceived(path, data);
        }
    }

}
